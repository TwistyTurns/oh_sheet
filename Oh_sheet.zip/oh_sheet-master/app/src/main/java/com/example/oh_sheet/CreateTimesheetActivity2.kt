package com.example.oh_sheet

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class CreateTimesheetActivity2 : AppCompatActivity() {

    var b = Bundle()

    val array = ArrayList<String?>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_timesheet2)

        b.putStringArrayList("key", array)

        //val i = Intent(context, Class)
    }
}